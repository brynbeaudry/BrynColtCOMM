package ca.bcit.comp2526.a3a.mazesolver;

import java.awt.Color;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Random;

/**
 * Maze.
 *
 * @author BCIT
 * @version 2016
 */
public class Maze {
    public static final int SIDES = 4;
    private final MazeSection[][] mazeSections;
    private final Random random;
    private int rows, columns;

    /**
     * Constructor for objects of type Maze.
     * 
     * @param rows
     * @param columns
     */
    public Maze(int rows, int columns) {
        mazeSections = new MazeSection[rows][columns];
        random = new Random();
        this.rows = rows;
        this.columns = columns;
    }

    /**
     * Initializes a new empty maze.
     */
    public void init() {
        for(int i = 0; i < rows; i++){
            for(int j = 0; j < columns; j++){
                mazeSections[i][j] = new MazeSection(i,j,false);
            }
        }
    }

    /**
     * Eliminates all walls from the maze and 'unvisits' each maze section,
     * effectively wiping it clean.
     */
    public void clear() {
        for(int i = 0; i < rows; i++){
            for(int j = 0; j < columns; j++){
                mazeSections[i][j].unvisit();
                mazeSections[i][j].setColour(Color.white);
            }
        }
    }

    /**
     * Makes the specified MazeSection solid.
     * 
     * @param section
     *            a maze
     */
    private void makeSolid(MazeSection section) {
        section.setSolid(true);
    }

    /**
     * Makes the specified MazeSection navigable.
     * 
     * @param section
     *            a maze
     */
    private void makeNavigable(MazeSection section) {
        section.setSolid(false);
    }

    /**
     * @return the number of rows
     */
    public int getRows() {
        return rows;
    }

    /**
     * @return the number of columns
     */
    public int getColumns() {
        return columns;
    }

    /**
     * Returns a reference to the MazeSection at the specified coordinates.
     * 
     * @param row
     * @param column
     * @return location in maze as a MazeSection
     */
    public MazeSection getMazeSectionAt(int row, int column) {
        return mazeSections[row][column];
    }

    /**
     * Generates a (terrible) random maze.
     */
    public void generateRandomMaze() {
        for(int i = 0; i < rows; i++){
            for(int j = 0; j < columns; j++){
                mazeSections[i][j].unvisit();
                mazeSections[i][j].setSolid(true);
            }
        }
        clearPath(0,1);
        for(int i = 0; i < rows; i++){
            for(int j = 0; j < columns; j++){
                mazeSections[i][j].resetAdj();
            }
        }
    }
    
    private void clearPath(int row, int column) {
        int randDir,temp;
        int max = SIDES + 1;
        if(row < 0 || row >= 25 || column < 0 || column >= 25 ||
                mazeSections[row][column].getAdj() > 1 ||
                mazeSections[row][column].hasBeenVisited())
            return;
        mazeSections[row][column].visit();
        mazeSections[row][column].setSolid(false);
        if(row > 1)
            mazeSections[row-1][column].incAdj();
        if(column > 1)
            mazeSections[row][column-1].incAdj();
        if(row < rows-1)
            mazeSections[row+1][column].incAdj();
        if(column < columns-1)
            mazeSections[row][column+1].incAdj();
        if(column == columns-1)
            return;
        int choices[] = new int[SIDES];
        for(int i = 0; i < SIDES; i++)
            choices[i] = i;
        for(int j = 0; j < SIDES; j++){
            randDir = random.nextInt(--max);
            switch(choices[randDir]){
                case 0: clearPath(row-1,column);
                case 1: clearPath(row,column-1);
                case 2: clearPath(row+1,column);
                case 3: clearPath(row,column+1);
            }
            temp = choices[randDir];
            choices[randDir] = choices[max-1];
            choices[max-1] = temp;
        }
    }

    /**
     * Generates a maze from the specified file. The file must be a .txt file
     * which contains MAZE_DIMENSION lines of MAZE_DIMENSION characters each.
     * There are two characters: * delineates a solid section, and anything
     * else delineates a navigable section. The entry to the maze must be at
     * location [0][1] and the (possibly multiple) exit(s) to the maze must be
     * on the right edge (rightmost column) of the maze [0...24][24]
     * 
     * @param file
     *            that contains the maze
     */
    public void generateMazeFromFile(File file) throws IOException {
        FileInputStream fileInput = new FileInputStream(file);
        int n;
        int col = 0;
        int row = 0;
        while (row < rows && (n = fileInput.read()) != -1) {
           char c = (char) n;
           if(c == '*')
               mazeSections[row][col].setSolid(true);
           if(++col >= columns)
               row++;
        }
        fileInput.close();
    }

    /**
     * Resets the maze by 'unvisiting' all visited maze sections
     * and resetting their colour to white.
     */
    public void reset() {
        for(int i = 0; i < rows; i++){
            for(int j = 0; j < columns; j++){
                mazeSections[i][j].unvisit();
                mazeSections[i][j].setSolid(false);
            }
        }
    }
}
