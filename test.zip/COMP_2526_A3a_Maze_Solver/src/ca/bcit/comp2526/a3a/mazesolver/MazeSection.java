package ca.bcit.comp2526.a3a.mazesolver;

import java.awt.Color;
import java.awt.Point;
//import java.awt.event.MouseAdapter;
//import java.awt.event.MouseEvent;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.border.Border;

/**
 * MazeSection.
 *
 * @author Colt King
 * @version 2016
 */
@SuppressWarnings("serial")
public class MazeSection extends JPanel {
    private final Point location;
    private boolean isSolid, visited;
    private Border mazeBord;
    private int adjCells;

    /**
     * Constructor for objects of type MazeSection.
     * 
     * @param maze
     * @param row
     * @param column
     * @param isSolid
     */
    public MazeSection(int row, int column, boolean isSolid) {
        location = new Point(row,column);
        this.isSolid = isSolid;
        visited = false;
        init();
    }

    /**
     * Initializes this maze section.
     */
    public void init() {
        mazeBord = BorderFactory.createLineBorder(new Color(0,0,0));
        setBorder(mazeBord);
        if(isSolid)
            setBackground(Color.black);
        else
            setBackground(Color.white);
    }

    /**
     * @return true if this maze section is solid, else false
     */
    public boolean isSolid() {
        return isSolid;
    }

    /**
     * Sets whether this maze section is solid.
     * 
     * @param isSolid a boolean
     */
    public void setSolid(boolean isSolid) {
        this.isSolid = isSolid;
        if(isSolid)
            setColour(Color.black);
        else
            setColour(Color.white);
    }

    /**
     * Visits this maze section.
     */
    public void visit() {
        visited = true;
        setColour(Color.gray);
    }

    /**
     * "Unvisits" this maze section.
     */
    public void unvisit() {
        visited = false;
        setColour(Color.white);
    }

    /**
     * @return true if this maze has been visited, else false
     */
    public boolean hasBeenVisited() {
        return visited;
    }

    /**
     * @return the location of this MazeSection as a Point
     */
    public Point getLocation() {
        return location;
    }

    /**
     * Sets the colour of this maze section.
     * 
     * @param color
     */
    public void setColour(Color color) {
       setBackground(color);
    }
    
    /**
     * @return the number of adjacent paths 
     */
    public int getAdj() {
        return adjCells;
    }
    
    /**
     * Sets the number of adjacent paths to zero.
     */
    public void resetAdj(){
        adjCells = 0;
    }
    
    /**
     * Increments the number of adjacent paths by one.
     */
    public void incAdj(){
        adjCells++;
    }
}
